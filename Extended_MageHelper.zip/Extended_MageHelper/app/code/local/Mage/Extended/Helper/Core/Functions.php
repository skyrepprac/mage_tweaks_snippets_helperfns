<?php
class Mage_Extended_Helper_Core_Functions extends Mage_Core_Helper_Data
{
	public function highlightWords($content, $word, $colors)
	{
		$color_index = 0;
		foreach( $words as $word ) {
			$content = self::_highlightWord($content, $word, $colors[$color_index]);
			$color_index = ( $color_index + 1 ) % count( $colors );
		}
		return $content;
	}

	private function _highlightWord($content, $word, $color)
	{
		$replace = '<span style="background-color: ' . $color . ';">' . $word . '</span>';
		$content = str_replace($word, $replace, $content);
		return $content;
	}

	/*public function searchCollection($collection)
	{
	}*/

	public function getBasePath($type = 'absolute')
	{
		if($type == 'relative') {
			//return realpath(__DIR__);
			return realpath(dirname(__FILE__));
			return substr($_SERVER['SCRIPT_NAME'], 0, strpos($_SERVER['SCRIPT_NAME'],basename($_SERVER['SCRIPT_NAME'])));
		} else {
			return Mage::getBaseDir();
		}
	}

	public function findInStaticContent($needle)
	{
		$staticBlocks = Mage::getModel('cms/block')
							->getCollection()
							->addFieldToSelect('identifier')
							/*->addFieldToFilter('content', array(
												array('like' => '% '.$needle.' %'),
												array('like' => '% '.$needle),
												array('like' => $needle.' %')
											));*/
							->addFieldToFilter('content', array('regexp' => '[[:<:]]'.$needle.'[[:>:]]'));
		$staticPages = Mage::getModel('cms/page')
							->getCollection()
							->addFieldToSelect('identifier')
							/*->addFieldToFilter('content', array(
												array('like' => '% '.$needle.' %'),
												array('like' => '% '.$needle),
												array('like' => $needle.' %')
											));*/
							->addFieldToFilter('content', array('regexp' => '[[:<:]]'.$needle.'[[:>:]]'));
		$searchResult['static_blocks'] = $staticBlocks->getData();
		$searchResult['static_pages'] = $staticPages->getData();
		return $searchResult;
	}

	public function getActualProducts()
	{
		$collection = Mage::getModel('catalog/product')->getCollection()->addAttributeToSelect('*');
		$collection->addFieldToFilter('visibility', Mage_Catalog_Model_Product_Visibility::VISIBILITY_BOTH)
				->addAttributeToFilter('status', array('eq' => Mage_Catalog_Model_Product_Status::STATUS_ENABLED));
		return $collection;
	}

	public function getActualCategories()
	{
		$_helper = Mage::helper('catalog/category');
		$_categories = $_helper->getStoreCategories();
		if (count($_categories) > 0) {
		    foreach($_categories as $_category) {
		        $_category = Mage::getModel('catalog/category')->load($_category->getId());
		        $_subcategories = $_category->getChildrenCategories();
		        if (count($_subcategories) > 0) {
		            echo $_category->getName();
		            echo $_category->getId();
		            foreach($_subcategories as $_subcategory) {
		                 echo $_subcategory->getName();
		                 echo $_subcategory->getId();
		            }
		        }
		    }
		}
	}

	public function purgeMageCache()
	{
		$cacheDir = Mage::getBaseDir().DS."var".DS."cache";
		try {
			//CLEAN OVERALL CACHE
			flush();
			Mage::app()->cleanCache();
			// CLEAN IMAGE CACHE
			flush();
			Mage::getModel('catalog/product_image')->clearCache();
			//Remove all the cache directories
			print '<pre>All magento caches were cleared successfully</pre>';
			//$this->_purgeFolder($cacheDir);
			$this->_emptyFolder($cacheDir);
		} catch(Exception $e) {
			print($e->getMessage());
		}
	}

	private function _purgeFolder($folder)
	{
		$files = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator($folder, RecursiveDirectoryIterator::SKIP_DOTS),
			RecursiveIteratorIterator::CHILD_FIRST);
		foreach ($files as $fileinfo) {
			$todo = ($fileinfo->isDir() ? 'rmdir' : 'unlink');
			$todo($fileinfo->getRealPath());
		}
		rmdir($folder);
		return true;
	}

	private function _emptyFolder($folder)
	{
		$di = new RecursiveDirectoryIterator($folder, FilesystemIterator::SKIP_DOTS);
		$ri = new RecursiveIteratorIterator($di, RecursiveIteratorIterator::CHILD_FIRST);
		foreach ( $ri as $file ) {
			$file->isDir() ?  rmdir($file) : unlink($file);
		}
		return true;
	}
}