<?php
require_once 'app/Mage.php';
Varien_Profiler::enable();
Mage::setIsDeveloperMode(true);
error_reporting(E_ALL);
ini_set('display_errors', 1);
umask(0);
Mage::app();

$products = Mage::helper('extended/core_functions')->getActualProducts();
echo "<pre/>"; print_r($products->getData()); die("<br/>Data printed above !!!");